/* =============================================
   practice.js
   Purpose: A cleaned-up collection of JavaScript
   fundamentals exercises (originally ak_1.js).

   The original file was a scratchpad of commented
   -out snippets. Here each concept is turned into
   a small, named, runnable function so it's easy
   to study, test, and reuse. Run any function by
   calling it at the bottom of the file.
============================================= */

// -----------------------------------------------
// 1. for...of loop — counting characters in a string
// -----------------------------------------------
function countCharacters(str) {
  let size = 0;
  for (const char of str) {
    size++;
  }
  console.log(`"${str}" has ${size} characters.`);
  return size;
}

// -----------------------------------------------
// 2. for...in loop — looping over object keys
// -----------------------------------------------
function printStudentInfo(student) {
  for (const key in student) {
    console.log(`${key}: ${student[key]}`);
  }
}

// -----------------------------------------------
// 3. for loop with condition — counting even numbers
// -----------------------------------------------
function countEvenNumbers(limit) {
  let count = 0;
  for (let i = 0; i <= limit; i++) {
    if (i % 2 === 0) {
      count++;
    }
  }
  console.log(`There are ${count} even numbers between 0 and ${limit}.`);
  return count;
}

// -----------------------------------------------
// 4. String methods — uppercase, lowercase, trim
// -----------------------------------------------
function demoStringCasing(text) {
  console.log("Original:", text);
  console.log("Uppercase:", text.toUpperCase());
  console.log("Lowercase:", text.toLowerCase());
  console.log("Trimmed:", text.trim());
}

// -----------------------------------------------
// 5. slice, concat, replace, replaceAll, charAt
// -----------------------------------------------
function demoStringMethods() {
  const sentence = "My name is Wasiq Bashir";

  console.log("slice(11):", sentence.slice(11));       // "Wasiq Bashir"
  console.log("slice(0, 14):", sentence.slice(0, 14));  // "My name is Was"

  const firstName = "Wasiq";
  const lastName = "Bashir";
  console.log("concat:", firstName.concat(" ", lastName));

  const greeting = "hello";
  console.log("replace first 'l':", greeting.replace("l", "y"));
  console.log("replaceAll 'l':", greeting.replaceAll("l", "y"));

  console.log("charAt(5):", sentence.charAt(5));
}

// -----------------------------------------------
// 6. Template literals — building strings cleanly
// -----------------------------------------------
function describeOrder(order) {
  // Template literals let us embed variables directly
  // inside a string using ${...} instead of string
  // concatenation with "+".
  return `Order: ${order.item}, Quantity: ${order.quantity}, Price: $${order.price}`;
}

// -----------------------------------------------
// 7. Simple username generator
// -----------------------------------------------
function generateUsername(fullName) {
  const cleanedName = fullName.toLowerCase().replaceAll(" ", "");
  return `@${cleanedName}${cleanedName.length}`;
}

// -----------------------------------------------
// 8. Array basics — looping and calculating an average
// -----------------------------------------------
function calculateAverage(marks) {
  let sum = 0;
  for (const mark of marks) {
    sum += mark;
  }
  const average = sum / marks.length;
  console.log(`Sum: ${sum}, Average: ${average.toFixed(2)}`);
  return average;
}

// -----------------------------------------------
// 9. Array methods — push, pop, splice, etc.
// -----------------------------------------------
function demoArrayMethods() {
  const fruits = ["Apple", "Banana", "Orange", "Peach", "Apricot"];
  console.log("Original array:", fruits);

  fruits.push("Cherry", "Kiwi");
  console.log("After push:", fruits);

  const removedFruit = fruits.pop();
  console.log("After pop, removed:", removedFruit, "->", fruits);

  fruits.unshift("Watermelon");
  console.log("After unshift:", fruits);

  // splice(start, deleteCount, ...itemsToAdd)
  fruits.splice(1, 1, "Dragon Fruit");
  console.log("After splice (replace):", fruits);
}

// -----------------------------------------------
// 10. A simple, reusable sum function
//     (Originally had a bug: "s" was never declared
//     with let/const, which silently creates a global
//     variable — a common source of hard-to-find bugs.)
// -----------------------------------------------
function sum(a, b) {
  const total = a + b;
  return total;
}

// -----------------------------------------------
// Run a few examples when this file is loaded directly.
// Comment/uncomment lines below to try different demos.
// -----------------------------------------------
countCharacters("Hello World");

printStudentInfo({ name: "Akshay", age: 22, city: "Pune" });

countEvenNumbers(100);

demoStringCasing("   Software Engineer   ");

demoStringMethods();

console.log(describeOrder({ item: "Pen", quantity: 6, price: 10 }));

console.log(generateUsername("Wasiq Bashir"));

calculateAverage([89, 72, 91, 68, 94, 74]);

demoArrayMethods();

console.log("sum(5, 6) =", sum(5, 6));
