/* =============================================
   script.js
   Purpose: Adds basic client-side validation to
   the login form in index.html.

   NOTE: This is a beginner-friendly demo. It does
   NOT send data anywhere or check real passwords —
   it only checks that the fields "look" valid
   before the (fake) sign-in happens. Wiring this to
   a real backend is a great "next step" project.
============================================= */

// Grab references to the elements we need to work with.
// Doing this once at the top avoids repeating document.getElementById().
const loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const emailError = document.getElementById("emailError");
const passwordError = document.getElementById("passwordError");
const submitBtn = document.getElementById("submitBtn");

/**
 * Checks whether a string looks like a valid email address.
 * This is a simple beginner-level check, not a full RFC validator.
 * @param {string} email - the text typed into the email field
 * @returns {boolean} true if it looks like a valid email
 */
function isValidEmail(email) {
  // A basic pattern: something@something.something
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
}

/**
 * Shows an error message under a field and highlights the input.
 * @param {HTMLElement} inputEl - the <input> element with the problem
 * @param {HTMLElement} errorEl - the <span> where the message is shown
 * @param {string} message - the text to display to the user
 */
function showError(inputEl, errorEl, message) {
  inputEl.classList.add("input-error");
  errorEl.textContent = message;
}

/**
 * Clears any previous error message and highlight from a field.
 * @param {HTMLElement} inputEl - the <input> element to reset
 * @param {HTMLElement} errorEl - the <span> to clear
 */
function clearError(inputEl, errorEl) {
  inputEl.classList.remove("input-error");
  errorEl.textContent = "";
}

/**
 * Runs all validation checks on the form.
 * @returns {boolean} true if every field passes validation
 */
function validateForm() {
  let isFormValid = true;

  // --- Check email ---
  const emailValue = emailInput.value.trim();
  if (emailValue === "") {
    showError(emailInput, emailError, "Email is required.");
    isFormValid = false;
  } else if (!isValidEmail(emailValue)) {
    showError(emailInput, emailError, "Please enter a valid email address.");
    isFormValid = false;
  } else {
    clearError(emailInput, emailError);
  }

  // --- Check password ---
  const passwordValue = passwordInput.value;
  if (passwordValue === "") {
    showError(passwordInput, passwordError, "Password is required.");
    isFormValid = false;
  } else if (passwordValue.length < 6) {
    showError(passwordInput, passwordError, "Password must be at least 6 characters.");
    isFormValid = false;
  } else {
    clearError(passwordInput, passwordError);
  }

  return isFormValid;
}

/**
 * Handles the form submission event.
 * Prevents the page from reloading, runs validation,
 * and (for demo purposes) logs a success message.
 * @param {SubmitEvent} event - the form submit event
 */
function handleLoginSubmit(event) {
  // Stop the browser's default "reload the page" behavior
  event.preventDefault();

  const isValid = validateForm();

  if (isValid) {
    // In a real app, this is where you'd send the data to a server
    // using fetch() or an API call. For now we just simulate success.
    submitBtn.disabled = true;
    submitBtn.textContent = "Signing in...";

    setTimeout(() => {
      alert("Login successful! (This is a demo — no real account was created.)");
      submitBtn.disabled = false;
      submitBtn.textContent = "Sign In";
      loginForm.reset();
    }, 1000);
  }
}

// Listen for the form being submitted (clicking "Sign In" or pressing Enter)
loginForm.addEventListener("submit", handleLoginSubmit);

// Bonus: clear an error as soon as the user starts fixing that field
emailInput.addEventListener("input", () => clearError(emailInput, emailError));
passwordInput.addEventListener("input", () => clearError(passwordInput, passwordError));
