# 📖 Project Overview

## What is this project?

This repository is a beginner-to-intermediate front-end learning project with two parts:

1. **Login UI** (`index.html`, `css/style.css`, `js/script.js`) — a realistic, styled login page you'd find in a small SaaS app, with working client-side validation.
2. **JavaScript Fundamentals Practice** (`js/practice.js`) — a set of small, documented functions covering loops, strings, template literals, and arrays.

## Why two parts in one repo?

The login page demonstrates applied skills (structuring a real UI, wiring up validation). The practice file demonstrates foundational understanding (the building blocks that make the UI code possible). Keeping them together tells a complete learning story: fundamentals → applied project.

## Who is this for?

- Beginners learning JavaScript who want to see practice snippets turned into clean, reusable code
- Anyone who wants a lightweight, dependency-free login page template to build on top of

## What this project is *not*

- It is **not** a real authentication system — there is no backend, no database, and no real password checking. `js/script.js` only validates that the input *looks* correct before simulating a successful login.
