# 🏗️ Project Architecture

## File relationships

```
index.html
   │
   ├── links to ──▶ css/style.css     (all visual styling)
   │
   └── loads    ──▶ js/script.js       (form validation logic)

js/practice.js  ── standalone, not linked from index.html.
                    Open it directly, or run with `node js/practice.js`,
                    to study JavaScript fundamentals independently.
```

## Why this structure?

- **Separation of concerns**: HTML handles structure, CSS handles appearance, JS handles behavior. Each file can be edited without touching the others.
- **`script.js` vs `practice.js`**: `script.js` is *application code* — it exists to make the login page work. `practice.js` is *learning code* — it exists to demonstrate understanding of JS fundamentals. Keeping them separate avoids mixing "demo/scratch" code with "real" app code, which is a habit professional codebases rely on.
- **`docs/` folder**: keeps explanatory writing (this file, learning notes, etc.) out of the README so the README stays scannable, while deeper explanations are still available for anyone who wants them.

## Data flow (login form)

1. User types into the email/password fields.
2. On submit, `handleLoginSubmit()` in `script.js` runs.
3. `event.preventDefault()` stops the page from reloading.
4. `validateForm()` checks both fields and calls `showError()` or `clearError()` as needed.
5. If valid, the button is disabled, a `setTimeout` simulates a network request, then the form resets.

There is no real network call in this version — that's the natural next step (see `LEARNING_NOTES.md`).
