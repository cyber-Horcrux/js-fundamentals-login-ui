# 🔍 Code Explanation

## `css/style.css`

- Uses a `radial-gradient` + `linear-gradient` stack on `body` for the glowing background effect.
- `body::before` and `body::after` add two blurred colored circles behind the card using pseudo-elements — a common trick to add decoration without extra HTML.
- `.login-card` uses `backdrop-filter: blur(18px)` for the frosted-glass look (this is what "glassmorphism" refers to).
- `.input-error` and `.error-text` are new classes added specifically to support the validation logic in `script.js`.

## `js/script.js`

| Function | What it does |
|---|---|
| `isValidEmail(email)` | Tests a string against a simple regex to check it looks like `name@domain.tld` |
| `showError(inputEl, errorEl, message)` | Adds a red highlight to an input and displays a message below it |
| `clearError(inputEl, errorEl)` | Removes the highlight and message once a field is fixed |
| `validateForm()` | Runs both field checks and returns `true`/`false` for the whole form |
| `handleLoginSubmit(event)` | The event handler wired to the form's `submit` event; orchestrates validation and the simulated sign-in |

Key JS concepts used: DOM selection (`getElementById`), event listeners, regex, template literals, `classList`, and `setTimeout`.

## `js/practice.js`

Each numbered section corresponds to one JavaScript concept, turned into a small function:

1. `countCharacters` — `for...of` over a string
2. `printStudentInfo` — `for...in` over an object's keys
3. `countEvenNumbers` — a standard counting `for` loop
4. `demoStringCasing` — `.toUpperCase()`, `.toLowerCase()`, `.trim()`
5. `demoStringMethods` — `.slice()`, `.concat()`, `.replace()`, `.replaceAll()`, `.charAt()`
6. `describeOrder` — template literals for string building
7. `generateUsername` — combining string methods into a small utility
8. `calculateAverage` — looping an array to compute a sum/average
9. `demoArrayMethods` — `.push()`, `.pop()`, `.unshift()`, `.splice()`
10. `sum` — the smallest example, and a reminder of why `let`/`const` matter

### Bug fixed from the original file

The original `sum()` function assigned to a variable `s` without declaring it:

```js
// Before (creates an accidental global variable)
function sum(a, b) {
    s = a + b;
    return s;
}
```

```js
// After (properly scoped)
function sum(a, b) {
    const total = a + b;
    return total;
}
```

Without `let`/`const`/`var`, JavaScript silently creates a **global variable** the first time you assign to an undeclared name. In a small script this is harmless, but in a larger app it can overwrite other variables and cause bugs that are hard to trace. Always declare your variables.
