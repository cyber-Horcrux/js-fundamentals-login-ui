# 🎓 Learning Notes

## JavaScript Concepts Used

- Variables: `let`, `const`
- Loops: `for`, `for...of`, `for...in`
- Functions: declarations, parameters, return values
- Template literals (`` `${variable}` ``)
- String methods: `.toUpperCase()`, `.toLowerCase()`, `.trim()`, `.slice()`, `.concat()`, `.replace()`, `.replaceAll()`, `.charAt()`
- Array methods: `.push()`, `.pop()`, `.unshift()`, `.shift()`, `.splice()`, `.concat()`
- Objects and property access (`for...in`, dot/bracket notation)
- DOM manipulation: `getElementById`, `classList.add/remove`, `textContent`
- Events: `addEventListener`, `preventDefault`
- Regex basics (email validation pattern)
- Asynchronous-feeling code with `setTimeout`

## HTML Concepts Used

- Semantic structure: `<form>`, `<label>`, `<input>`, `<button>`
- Accessibility basics: `for`/`id` pairing between `<label>` and `<input>`
- Input types: `email`, `password`, `checkbox`
- Meta tags: viewport, description

## CSS Concepts Used

- Flexbox (`display: flex`) for form and layout structure
- CSS Grid (`display: grid; place-items: center`) for centering
- Gradients: `linear-gradient`, `radial-gradient`
- `backdrop-filter` for glassmorphism
- Pseudo-elements (`::before`, `::after`)
- Responsive design with `@media` queries
- CSS custom transitions and hover states

## Difficulty Level

**Beginner → Early-Intermediate.** The HTML/CSS is intermediate (glassmorphism, gradients, responsive design). The JavaScript is solidly beginner: variables, loops, functions, basic DOM work — no frameworks, no async/await, no classes.

## What to Learn Next

1. **Forms → Backend**: Learn Node.js + Express to actually receive form submissions
2. **Fetch API**: Replace the simulated `setTimeout` login with a real `fetch()` call
3. **LocalStorage / SessionStorage**: Persist "remember me" state
4. **Basic testing**: Try Jest to write your first unit tests for `practice.js` functions
5. **A CSS framework or preprocessor**: Try Sass or Tailwind to compare workflows
6. **Version control habits**: Practice branching and pull requests, even solo

---

## 🚀 30+ Future Improvements

### Login Page
1. Add a "show/hide password" eye icon toggle
2. Add password strength meter
3. Add real backend authentication (Node/Express + database)
4. Add "Sign in with Google" / OAuth buttons
5. Add loading spinner instead of just disabling the button
6. Add toast notifications instead of `alert()`
7. Persist "Remember me" using `localStorage`
8. Add a matching Sign Up page
9. Add a matching "Forgot Password" flow
10. Add dark/light theme toggle
11. Add animated transitions between form states
12. Add keyboard accessibility testing (tab order, focus rings)
13. Add ARIA attributes for screen reader support
14. Add unit tests for `isValidEmail()` and `validateForm()`
15. Add rate-limiting feedback (e.g., "too many attempts")
16. Convert to a component-based framework (React/Vue) as a stretch goal
17. Add multi-language support (i18n)
18. Add a favicon and page title per view
19. Add form autofill hints (`autocomplete="email"`, etc.)
20. Add a real screenshot to `assets/screenshots/`

### JavaScript Practice File
21. Turn each function in `practice.js` into a small Jest test suite
22. Add array methods not yet covered: `.map()`, `.filter()`, `.reduce()`, `.find()`
23. Add examples of `try/catch` error handling
24. Add examples of `async/await` with a mock API call
25. Add a section on destructuring (objects and arrays)
26. Add a section on the spread/rest operators
27. Add a section on `Map` and `Set`
28. Add JSDoc types throughout for stronger IDE autocompletion
29. Turn `practice.js` into an interactive browser quiz (ask a question, check the answer)
30. Add a linter (ESLint) and formatter (Prettier) config

### Repo / Process
31. Add GitHub Actions to auto-run tests/lint on every push
32. Add a `CONTRIBUTING.md` for open-source style contributions
33. Add GitHub Issue and PR templates
34. Tag a `v1.0.0` release once the backend is added
